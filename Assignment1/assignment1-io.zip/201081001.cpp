#include<bits/stdc++.h>
using namespace std;

bool isfull(int top, int n)
{

	if (top==n-1)
	{
		return 0;
	}
	else
	{
		return 1;
	}
}

bool isempty(int top )
{

	if (top==-1)
	{
		return 0;
	}
	else
	{
		return 1;
	}
}

void push(int top, int value, int* arr)
{	
	arr[top] = value;	
}

void pop(int top, int value, int* arr)
{	
	arr[top] = -1;	
}

int main(int argc, char const *argv[])
{
	
	int n;
	cin>>n;
	int arr[n];
	int value;
	// int top=-1;

	// push(top, value, arr);
	int top=-1;
	while (1)
	{
		cin>>value;
		if(!isfull(top,n))
		{
			cout<<"Stack overflow"<<endl;
			break;
		}
		else
			top++;
			push(top, value, arr);

		for (int i = 0; i < n; ++i)
		{
			cout<<arr[i]<<" ";
		}
		cout<<endl;			
	}





	cout<<top<<endl;
	while (1)
	{
		
		if(!isempty(top))
		{
			cout<<"Stack underflow"<<endl;
			break;
		}
		else
			
			pop(top, value, arr);
			top--;

		for (int i = 0; i < n; ++i)
		{
			cout<<arr[i]<<" ";
		}	
		cout<<endl;
	}


	return 0;
}